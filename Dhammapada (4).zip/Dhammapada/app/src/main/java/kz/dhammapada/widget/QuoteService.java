package kz.dhammapada.widget;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.IBinder;
import android.widget.RemoteViews;

/**
 * Держит окошко с цитатой на экране блокировки (уведомление под часами)
 * и, если включено, меняет цитату при каждом выключении экрана.
 */
public class QuoteService extends Service {

    static final String CHANNEL_ID = "quote_lockscreen";
    static final int NOTIFICATION_ID = 1;

    private BroadcastReceiver screenReceiver;

    static boolean needed(Context c) {
        return LockScreen.isEnabled(c) || Settings.changeOnScreen(c);
    }

    /** Запустить или остановить сервис в зависимости от настроек. */
    static void sync(Context c) {
        Intent i = new Intent(c, QuoteService.class);
        try {
            if (needed(c)) {
                c.startForegroundService(i);
            } else {
                c.stopService(i);
                c.getSystemService(NotificationManager.class).cancel(NOTIFICATION_ID);
            }
        } catch (Throwable ignored) {
        }
    }

    static void createChannel(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm.getNotificationChannel(CHANNEL_ID) != null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL_ID,
                Settings.t(c, "Цитата на экране блокировки", "Lock screen quote"),
                NotificationManager.IMPORTANCE_DEFAULT);
        ch.setSound(null, null);
        ch.enableVibration(false);
        ch.enableLights(false);
        ch.setShowBadge(false);
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(ch);
    }

    static Notification build(Context c) {
        int idx = QuoteStore.current(c);
        boolean en = Settings.english(c);
        String text = Quotes.text(idx, en);
        String source = Quotes.source(idx, en);

        RemoteViews small = new RemoteViews(c.getPackageName(), R.layout.notif_quote);
        small.setTextViewText(R.id.n_text, text);
        RemoteViews big = new RemoteViews(c.getPackageName(), R.layout.notif_quote_big);
        big.setTextViewText(R.id.n_text, text);
        big.setTextViewText(R.id.n_source, source);

        PendingIntent open = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent nextIntent = new Intent(c, QuoteWidgetProvider.class);
        nextIntent.setAction(QuoteWidgetProvider.ACTION_NEXT);
        PendingIntent next = PendingIntent.getBroadcast(c, 1, nextIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = new Notification.Builder(c, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(source)
                .setContentText(text)
                .setSubText(Settings.t(c, "стих ", "verse ") + Quotes.ALL[idx][0])
                .setStyle(new Notification.DecoratedCustomViewStyle())
                .setCustomContentView(small)
                .setCustomBigContentView(big)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setCategory(Notification.CATEGORY_STATUS)
                .setVisibility(LockScreen.isEnabled(c)
                        ? Notification.VISIBILITY_PUBLIC : Notification.VISIBILITY_SECRET)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(c, R.drawable.ic_notif),
                        Settings.t(c, "Следующая", "Next"), next).build());
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        return b.build();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel(this);
        goForeground();

        screenReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (Settings.changeOnScreen(context)) {
                    QuoteStore.next(context);
                    Refresher.refreshAll(context);
                }
            }
        };
        IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenReceiver, f, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(screenReceiver, f);
        }
    }

    private void goForeground() {
        Notification n = build(this);
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, n);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!needed(this)) {
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        }
        Refresher.checkBoot(this);
        goForeground();
        QuoteWidgetProvider.updateAll(this);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (screenReceiver != null) {
            try { unregisterReceiver(screenReceiver); } catch (Throwable ignored) { }
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
