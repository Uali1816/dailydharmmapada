package kz.dhammapada.widget;

import android.app.NotificationManager;
import android.content.Context;
import android.os.SystemClock;

/** Общие действия: проверка перезагрузки и обновление виджета + окошка на экране блокировки. */
final class Refresher {
    private Refresher() {}

    /** Если телефон был перезагружен с прошлого раза — выбрать новую цитату. */
    static boolean checkBoot(Context c) {
        long bootTime = System.currentTimeMillis() - SystemClock.elapsedRealtime();
        if (QuoteStore.markBoot(c, bootTime)) {
            QuoteStore.next(c);
            return true;
        }
        return false;
    }

    /** Показать текущую цитату везде. */
    static void refreshAll(Context c) {
        QuoteWidgetProvider.updateAll(c);
        if (QuoteService.needed(c)) {
            try {
                NotificationManager nm = c.getSystemService(NotificationManager.class);
                QuoteService.createChannel(c);
                nm.notify(QuoteService.NOTIFICATION_ID, QuoteService.build(c));
            } catch (Throwable ignored) {
            }
        }
    }
}
