package kz.dhammapada.widget;

import android.app.WallpaperManager;
import android.content.Context;
import android.content.SharedPreferences;

/** Настройка «цитата на экране блокировки» (показывается уведомлением под часами). */
final class LockScreen {
    private static final String PREFS = "quotes";
    private static final String KEY_ENABLED = "lock_enabled";
    private static final String KEY_LEGACY_DONE = "legacy_wallpaper_cleared";

    private LockScreen() {}

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static boolean isEnabled(Context c) { return p(c).getBoolean(KEY_ENABLED, false); }
    static void setEnabled(Context c, boolean on) { p(c).edit().putBoolean(KEY_ENABLED, on).apply(); }

    /** Старая версия ставила картинку обоями блокировки — нужно ли ещё её убрать. */
    static boolean legacyCleanupPending(Context c) {
        SharedPreferences sp = p(c);
        if (sp.getBoolean(KEY_LEGACY_DONE, false)) return false;
        // Приложение уже использовалось до версии 1.3 — значит, могла остаться старая картинка
        if (sp.contains("index") || sp.contains(KEY_ENABLED)) return true;
        // Новая установка — убирать нечего
        sp.edit().putBoolean(KEY_LEGACY_DONE, true).apply();
        return false;
    }
    static void markLegacyDone(Context c) { p(c).edit().putBoolean(KEY_LEGACY_DONE, true).apply(); }

    /** Убрать картинку с экрана блокировки: там снова будут обычные обои телефона. Не в главном потоке. */
    static boolean clearLegacyWallpaper(Context c) {
        try {
            WallpaperManager.getInstance(c).clear(WallpaperManager.FLAG_LOCK);
            markLegacyDone(c);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }
}
