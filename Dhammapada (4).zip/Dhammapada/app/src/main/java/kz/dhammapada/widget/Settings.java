package kz.dhammapada.widget;

import android.content.Context;
import android.content.SharedPreferences;

/** Настройки: язык, тема, когда менять цитату. */
final class Settings {
    private static final String PREFS = "quotes";
    private static final String KEY_EN = "english";
    private static final String KEY_DARK = "dark";
    private static final String KEY_SCREEN = "change_on_screen";

    private Settings() {}

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static boolean english(Context c) { return p(c).getBoolean(KEY_EN, false); }
    static void setEnglish(Context c, boolean v) { p(c).edit().putBoolean(KEY_EN, v).apply(); }

    static boolean dark(Context c) { return p(c).getBoolean(KEY_DARK, false); }
    static void setDark(Context c, boolean v) { p(c).edit().putBoolean(KEY_DARK, v).apply(); }

    /** true — новая цитата при каждом включении экрана; false — только после перезагрузки. */
    static boolean changeOnScreen(Context c) { return p(c).getBoolean(KEY_SCREEN, false); }
    static void setChangeOnScreen(Context c, boolean v) { p(c).edit().putBoolean(KEY_SCREEN, v).apply(); }

    static String t(Context c, String ru, String en) { return english(c) ? en : ru; }
}
