package kz.dhammapada.widget;

import android.content.Context;
import android.os.SystemClock;

/** Проверка перезагрузки и обновление виджетов. */
final class Refresher {
    private Refresher() {}

    /** Если телефон был перезагружен с прошлого раза — выбрать новую цитату. */
    static boolean checkBoot(Context c) {
        long bootTime = System.currentTimeMillis() - SystemClock.elapsedRealtime();
        if (QuoteStore.markBoot(c, bootTime)) {
            QuoteStore.next(c);
            return true;
        }
        return false;
    }

    static void refreshAll(Context c) {
        QuoteWidgetProvider.updateAll(c);
    }
}
