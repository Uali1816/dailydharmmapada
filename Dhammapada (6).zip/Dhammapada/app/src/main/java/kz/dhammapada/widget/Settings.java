package kz.dhammapada.widget;

import android.content.Context;
import android.content.SharedPreferences;

/** Настройки: язык, тема приложения, стиль виджета. */
final class Settings {
    private static final String PREFS = "quotes";
    private static final String KEY_EN = "english";
    private static final String KEY_DARK = "dark";
    private static final String KEY_STYLE = "widget_style";

    static final int STYLE_CLEAR = 0;  // прозрачный, белый текст — для экрана блокировки
    static final int STYLE_DARK = 1;
    static final int STYLE_LIGHT = 2;

    private Settings() {}

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static boolean english(Context c) { return p(c).getBoolean(KEY_EN, false); }
    static void setEnglish(Context c, boolean v) { p(c).edit().putBoolean(KEY_EN, v).apply(); }

    static boolean dark(Context c) { return p(c).getBoolean(KEY_DARK, false); }
    static void setDark(Context c, boolean v) { p(c).edit().putBoolean(KEY_DARK, v).apply(); }

    static int widgetStyle(Context c) { return p(c).getInt(KEY_STYLE, STYLE_CLEAR); }
    static void setWidgetStyle(Context c, int v) { p(c).edit().putInt(KEY_STYLE, v).apply(); }

    static String t(Context c, String ru, String en) { return english(c) ? en : ru; }
}
