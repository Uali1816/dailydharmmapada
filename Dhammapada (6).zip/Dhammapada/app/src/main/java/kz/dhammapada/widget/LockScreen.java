package kz.dhammapada.widget;

import android.app.WallpaperManager;
import android.content.Context;

/** Убрать картинку с цитатой, которую ставила первая версия, с экрана блокировки. */
final class LockScreen {
    private LockScreen() {}

    /** Не в главном потоке. После этого на экране блокировки будут обои главного экрана. */
    static boolean clearOldPicture(Context c) {
        try {
            WallpaperManager.getInstance(c).clear(WallpaperManager.FLAG_LOCK);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }
}
