package kz.dhammapada.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/** Виджет на главном экране. Нажатие на виджет — следующая цитата. */
public class QuoteWidgetProvider extends AppWidgetProvider {

    static final String ACTION_NEXT = "kz.dhammapada.widget.ACTION_NEXT";

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        if (Refresher.checkBoot(context)) {
            Refresher.refreshAll(context);
        }
        RemoteViews views = buildViews(context);
        for (int id : ids) {
            manager.updateAppWidget(id, views);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_NEXT.equals(intent.getAction())) {
            QuoteStore.next(context);
            Refresher.refreshAll(context);
        }
    }

    /** Обновить все размещённые виджеты. */
    static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, QuoteWidgetProvider.class));
        if (ids == null || ids.length == 0) return;
        RemoteViews views = buildViews(context);
        for (int id : ids) {
            manager.updateAppWidget(id, views);
        }
    }

    private static RemoteViews buildViews(Context context) {
        int idx = QuoteStore.current(context);
        boolean en = Settings.english(context);
        int style = Settings.widgetStyle(context);
        int layout = style == Settings.STYLE_DARK ? R.layout.widget_quote
                : style == Settings.STYLE_LIGHT ? R.layout.widget_quote_light
                : R.layout.widget_quote_clear;

        RemoteViews views = new RemoteViews(context.getPackageName(), layout);
        views.setTextViewText(R.id.quote_text, Quotes.text(idx, en));
        views.setTextViewText(R.id.quote_source, Quotes.source(idx, en));

        Intent next = new Intent(context, QuoteWidgetProvider.class);
        next.setAction(ACTION_NEXT);
        PendingIntent pi = PendingIntent.getBroadcast(context, 0, next,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, pi);
        return views;
    }
}
