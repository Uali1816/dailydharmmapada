package kz.dhammapada.widget;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Включение телефона: новая цитата на виджете. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Refresher.checkBoot(context);
        QuoteWidgetProvider.updateAll(context);
    }
}
