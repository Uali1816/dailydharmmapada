package kz.dhammapada.widget;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** Экран приложения: цитата, настройки виджета, помощь. */
public class MainActivity extends Activity {

    private TextView quoteView;
    private TextView sourceView;
    private float d;

    private int cBg, cText, cMuted, cCard, cCardText, cGold, cBtn, cBtnText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Refresher.checkBoot(this);
        buildUi();
    }

    private String t(String ru, String en) {
        return Settings.t(this, ru, en);
    }

    private void loadColors() {
        if (Settings.dark(this)) {
            cBg = Color.parseColor("#14110E");
            cText = Color.parseColor("#F1EAE0");
            cMuted = Color.parseColor("#A89B8B");
            cCard = Color.parseColor("#26201A");
            cCardText = Color.parseColor("#F5EFE6");
            cGold = Color.parseColor("#D4AF6A");
            cBtn = Color.parseColor("#332A21");
            cBtnText = Color.parseColor("#F1EAE0");
        } else {
            cBg = Color.parseColor("#F6F1E9");
            cText = Color.parseColor("#1E1B18");
            cMuted = Color.parseColor("#7A6E60");
            cCard = Color.parseColor("#1E1B18");
            cCardText = Color.parseColor("#F5EFE6");
            cGold = Color.parseColor("#B8924A");
            cBtn = Color.parseColor("#E8DFD2");
            cBtnText = Color.parseColor("#1E1B18");
        }
    }

    private void buildUi() {
        loadColors();
        d = getResources().getDisplayMetrics().density;
        int pad = (int) (24 * d);
        getWindow().setStatusBarColor(Settings.dark(this) ? cBg : Color.parseColor("#1E1B18"));
        getWindow().setNavigationBarColor(cBg);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(cBg);
        scroll.setFitsSystemWindows(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText(t("Дхаммапада", "Dhammapada"));
        title.setTextSize(28);
        title.setTypeface(Typeface.SERIF, Typeface.BOLD);
        title.setTextColor(cText);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText(t(Quotes.ALL.length + " изречений · новое после каждой перезагрузки телефона",
                Quotes.ALL.length + " verses · a new one after every phone restart"));
        subtitle.setTextSize(13);
        subtitle.setTextColor(cMuted);
        subtitle.setPadding(0, (int) (4 * d), 0, (int) (20 * d));
        root.addView(subtitle);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(pad, pad, pad, pad);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(cCard);
        bg.setCornerRadius(22 * d);
        card.setBackground(bg);
        root.addView(card);

        quoteView = new TextView(this);
        quoteView.setTextSize(19);
        quoteView.setTypeface(Typeface.SERIF);
        quoteView.setTextColor(cCardText);
        quoteView.setLineSpacing(0, 1.15f);
        card.addView(quoteView);

        sourceView = new TextView(this);
        sourceView.setTextSize(13);
        sourceView.setGravity(Gravity.END);
        sourceView.setTextColor(Color.parseColor("#D4AF6A"));
        sourceView.setPadding(0, (int) (12 * d), 0, 0);
        card.addView(sourceView);

        Button nextBtn = button(t("Другая цитата", "Another quote"), false);
        nextBtn.setOnClickListener(v -> {
            QuoteStore.next(this);
            showCurrent();
            Refresher.refreshAll(this);
        });
        root.addView(nextBtn, lp(16));

        AppWidgetManager awm = AppWidgetManager.getInstance(this);
        if (awm.isRequestPinAppWidgetSupported()) {
            Button pinBtn = button(t("Добавить виджет на главный экран", "Add widget to home screen"), false);
            pinBtn.setOnClickListener(v -> awm.requestPinAppWidget(
                    new ComponentName(this, QuoteWidgetProvider.class), null, null));
            root.addView(pinBtn, lp(8));
        }

        // Стиль виджета
        root.addView(header(t("Вид виджета", "Widget style")));
        LinearLayout styles = new LinearLayout(this);
        styles.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(styles, lp(0));
        addStyleButton(styles, Settings.STYLE_CLEAR, t("Прозрачный", "Clear"));
        addStyleButton(styles, Settings.STYLE_DARK, t("Тёмный", "Dark"));
        addStyleButton(styles, Settings.STYLE_LIGHT, t("Светлый", "Light"));
        TextView styleHint = new TextView(this);
        styleHint.setText(t("«Прозрачный» — белый текст прямо на обоях, как часы и погода на экране блокировки.",
                "“Clear” — white text right on your wallpaper, like the lock screen clock and weather."));
        styleHint.setTextSize(12);
        styleHint.setTextColor(cMuted);
        styleHint.setPadding(0, (int) (6 * d), 0, 0);
        root.addView(styleHint);

        // Настройки приложения
        root.addView(header(t("Приложение", "App")));

        Switch darkSwitch = sw(t("Тёмная тема", "Dark theme"));
        darkSwitch.setChecked(Settings.dark(this));
        darkSwitch.setOnCheckedChangeListener((b, on) -> {
            Settings.setDark(this, on);
            buildUi();
        });
        root.addView(darkSwitch, lp(0));

        Switch langSwitch = sw("English");
        langSwitch.setChecked(Settings.english(this));
        langSwitch.setOnCheckedChangeListener((b, on) -> {
            Settings.setEnglish(this, on);
            Refresher.refreshAll(this);
            buildUi();
        });
        root.addView(langSwitch, lp(0));

        // Помощь
        root.addView(header(t("Виджет на экране блокировки (Samsung)", "Widget on the lock screen (Samsung)")));
        TextView help = new TextView(this);
        help.setText(t(
                "Стандартный список виджетов экрана блокировки Samsung показывает только приложения Samsung. "
                        + "Чтобы поставить туда этот виджет:\n"
                        + "1. Установите Good Lock из Galaxy Store.\n"
                        + "2. В Good Lock установите модуль LockStar и включите его.\n"
                        + "3. В LockStar нажмите на экран блокировки → «Виджеты» → «Дхаммапада».\n"
                        + "4. Выберите вид «Прозрачный» выше — так виджет будет выглядеть как часы и погода.\n\n"
                        + "Главный экран: долго нажмите на пустое место → «Виджеты» → «Дхаммапада».\n\n"
                        + "Цитата меняется после каждой перезагрузки телефона. Нажатие на виджет — следующая цитата.",
                "Samsung's standard lock screen widget list shows only Samsung apps. "
                        + "To put this widget there:\n"
                        + "1. Install Good Lock from the Galaxy Store.\n"
                        + "2. In Good Lock, install the LockStar module and turn it on.\n"
                        + "3. In LockStar, tap the lock screen → “Widgets” → “Dhammapada”.\n"
                        + "4. Choose the “Clear” style above so it looks like the clock and weather.\n\n"
                        + "Home screen: long-press an empty spot → “Widgets” → “Dhammapada”.\n\n"
                        + "The quote changes after every phone restart. Tap the widget for the next quote."));
        help.setTextSize(14);
        help.setTextColor(cText);
        help.setAlpha(0.85f);
        help.setLineSpacing(0, 1.2f);
        root.addView(help);

        Button clearBtn = button(t("Убрать старую картинку с цитатой с экрана блокировки",
                "Remove the old quote picture from the lock screen"), false);
        clearBtn.setOnClickListener(v -> new Thread(() -> {
            boolean ok = LockScreen.clearOldPicture(getApplicationContext());
            runOnUiThread(() -> Toast.makeText(this,
                    ok ? t("Готово — на экране блокировки снова обои телефона",
                            "Done — the lock screen shows your wallpaper again")
                       : t("Не получилось — поменяйте обои вручную в настройках",
                            "Didn't work — change the wallpaper manually in Settings"),
                    Toast.LENGTH_LONG).show());
        }).start());
        root.addView(clearBtn, lp(20));

        TextView note = new TextView(this);
        String ver = "";
        try {
            ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
        }
        note.setText(t("Перевод изречений — вольный пересказ с пали.\nВерсия ",
                "Verses are a free rendering from the Pali.\nVersion ") + ver);
        note.setTextSize(12);
        note.setTextColor(cMuted);
        note.setPadding(0, (int) (16 * d), 0, 0);
        root.addView(note);

        setContentView(scroll);
        showCurrent();
        QuoteWidgetProvider.updateAll(this);
    }

    private void addStyleButton(LinearLayout row, int style, String label) {
        boolean selected = Settings.widgetStyle(this) == style;
        Button b = button(label, selected);
        b.setOnClickListener(v -> {
            Settings.setWidgetStyle(this, style);
            Refresher.refreshAll(this);
            buildUi();
        });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins((int) (2 * d), 0, (int) (2 * d), 0);
        row.addView(b, p);
    }

    private LinearLayout.LayoutParams lp(int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = (int) (topDp * d);
        return lp;
    }

    private Button button(String text, boolean selected) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(selected ? Color.parseColor("#1E1B18") : cBtnText);
        b.setBackgroundTintList(ColorStateList.valueOf(selected ? Color.parseColor("#D4AF6A") : cBtn));
        return b;
    }

    private Switch sw(String text) {
        Switch s = new Switch(this);
        s.setText(text);
        s.setTextSize(16);
        s.setTextColor(cText);
        s.setPadding(0, (int) (14 * d), 0, (int) (14 * d));
        ColorStateList thumb = new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                new int[]{Color.parseColor("#D4AF6A"),
                        Settings.dark(this) ? Color.parseColor("#8A7F72") : Color.parseColor("#FFFFFF")});
        ColorStateList track = new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                new int[]{Color.parseColor("#80D4AF6A"), Color.parseColor("#55888888")});
        s.setThumbTintList(thumb);
        s.setTrackTintList(track);
        return s;
    }

    private TextView header(String text) {
        TextView h = new TextView(this);
        h.setText(text);
        h.setTextSize(13);
        h.setLetterSpacing(0.06f);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        h.setTextColor(cGold);
        h.setPadding(0, (int) (28 * d), 0, (int) (6 * d));
        return h;
    }

    private void showCurrent() {
        int idx = QuoteStore.current(this);
        boolean en = Settings.english(this);
        quoteView.setText(Quotes.text(idx, en));
        sourceView.setText(Quotes.source(idx, en));
    }
}
