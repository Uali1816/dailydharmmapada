package kz.dhammapada.widget;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Включение телефона или обновление приложения: новая цитата и запуск окошка на экране блокировки. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Refresher.checkBoot(context);
        QuoteWidgetProvider.updateAll(context);
        QuoteService.sync(context);

        // Убрать картинку, которую ставила старая версия (один раз)
        if (LockScreen.legacyCleanupPending(context) && LockScreen.isEnabled(context)) {
            final Context app = context.getApplicationContext();
            final PendingResult result = goAsync();
            new Thread(() -> {
                try {
                    LockScreen.clearLegacyWallpaper(app);
                } finally {
                    result.finish();
                }
            }).start();
        }
    }
}
