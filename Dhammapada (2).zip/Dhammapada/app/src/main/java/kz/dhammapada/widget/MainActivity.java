package kz.dhammapada.widget;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** Экран приложения: цитата, настройки (язык, тема, экран блокировки), помощь. */
public class MainActivity extends Activity {

    private TextView quoteView;
    private TextView sourceView;
    private float d;

    // Цвета текущей темы
    private int cBg, cText, cMuted, cCard, cCardText, cGold, cBtn, cBtnText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private String t(String ru, String en) {
        return Settings.t(this, ru, en);
    }

    private void loadColors() {
        if (Settings.dark(this)) {
            cBg = Color.parseColor("#14110E");
            cText = Color.parseColor("#F1EAE0");
            cMuted = Color.parseColor("#A89B8B");
            cCard = Color.parseColor("#26201A");
            cCardText = Color.parseColor("#F5EFE6");
            cGold = Color.parseColor("#D4AF6A");
            cBtn = Color.parseColor("#332A21");
            cBtnText = Color.parseColor("#F1EAE0");
        } else {
            cBg = Color.parseColor("#F6F1E9");
            cText = Color.parseColor("#1E1B18");
            cMuted = Color.parseColor("#7A6E60");
            cCard = Color.parseColor("#1E1B18");
            cCardText = Color.parseColor("#F5EFE6");
            cGold = Color.parseColor("#D4AF6A");
            cBtn = Color.parseColor("#E8DFD2");
            cBtnText = Color.parseColor("#1E1B18");
        }
    }

    private void buildUi() {
        loadColors();
        d = getResources().getDisplayMetrics().density;
        int pad = (int) (24 * d);
        getWindow().setStatusBarColor(Settings.dark(this) ? cBg : Color.parseColor("#1E1B18"));
        getWindow().setNavigationBarColor(cBg);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(cBg);
        scroll.setFitsSystemWindows(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText(t("Дхаммапада", "Dhammapada"));
        title.setTextSize(28);
        title.setTypeface(Typeface.SERIF, Typeface.BOLD);
        title.setTextColor(cText);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText(t(Quotes.ALL.length + " изречений · новое при каждом включении телефона",
                Quotes.ALL.length + " verses · a new one every time the phone restarts"));
        subtitle.setTextSize(13);
        subtitle.setTextColor(cMuted);
        subtitle.setPadding(0, (int) (4 * d), 0, (int) (20 * d));
        root.addView(subtitle);

        // Карточка с цитатой
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(pad, pad, pad, pad);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(cCard);
        bg.setCornerRadius(22 * d);
        card.setBackground(bg);
        root.addView(card);

        quoteView = new TextView(this);
        quoteView.setTextSize(19);
        quoteView.setTypeface(Typeface.SERIF);
        quoteView.setTextColor(cCardText);
        quoteView.setLineSpacing(0, 1.15f);
        card.addView(quoteView);

        sourceView = new TextView(this);
        sourceView.setTextSize(13);
        sourceView.setGravity(Gravity.END);
        sourceView.setTextColor(cGold);
        sourceView.setPadding(0, (int) (12 * d), 0, 0);
        card.addView(sourceView);

        Button nextBtn = button(t("Другая цитата", "Another quote"));
        nextBtn.setOnClickListener(v -> {
            QuoteStore.next(this);
            showCurrent();
            refreshEverywhere(false);
        });
        root.addView(nextBtn, lp(16));

        AppWidgetManager awm = AppWidgetManager.getInstance(this);
        if (awm.isRequestPinAppWidgetSupported()) {
            Button pinBtn = button(t("Добавить виджет на главный экран", "Add widget to home screen"));
            pinBtn.setOnClickListener(v -> awm.requestPinAppWidget(
                    new ComponentName(this, QuoteWidgetProvider.class), null, null));
            root.addView(pinBtn, lp(8));
        }

        // Настройки
        root.addView(header(t("Настройки", "Settings")));

        Switch lockSwitch = sw(t("Цитата на экране блокировки", "Quote on lock screen"));
        lockSwitch.setChecked(LockScreen.isEnabled(this));
        lockSwitch.setOnCheckedChangeListener((b, on) -> {
            LockScreen.setEnabled(this, on);
            if (on) updateLockScreen(true);
        });
        root.addView(lockSwitch, lp(0));

        Switch darkSwitch = sw(t("Тёмная тема", "Dark theme"));
        darkSwitch.setChecked(Settings.dark(this));
        darkSwitch.setOnCheckedChangeListener((b, on) -> {
            Settings.setDark(this, on);
            QuoteWidgetProvider.updateAll(this);
            buildUi();
        });
        root.addView(darkSwitch, lp(0));

        Switch langSwitch = sw("English");
        langSwitch.setChecked(Settings.english(this));
        langSwitch.setOnCheckedChangeListener((b, on) -> {
            Settings.setEnglish(this, on);
            refreshEverywhere(false);
            buildUi();
        });
        root.addView(langSwitch, lp(0));

        // Помощь
        root.addView(header(t("Как пользоваться", "How to use")));

        TextView help = new TextView(this);
        help.setText(t(
                "Виджет: долго нажмите на пустое место главного экрана → «Виджеты» → найдите «Дхаммапада» "
                        + "и перетащите виджет на экран. Нажатие на виджет показывает следующую цитату.\n\n"
                        + "Экран блокировки: включите переключатель выше — приложение поставит картинку "
                        + "с цитатой обоями экрана блокировки (текущие обои блокировки будут заменены, "
                        + "обои главного экрана не меняются).\n\n"
                        + "После каждого выключения и включения телефона появляется новая цитата.\n\n"
                        + "На Xiaomi, Huawei, Honor и некоторых других телефонах разрешите приложению "
                        + "«Автозапуск» в настройках. На Xiaomi также выключите «Карусель обоев».",
                "Widget: long-press an empty spot on the home screen → “Widgets” → find “Dhammapada” "
                        + "and drag the widget onto the screen. Tap the widget to see the next quote.\n\n"
                        + "Lock screen: turn on the switch above — the app will set an image with the quote "
                        + "as your lock screen wallpaper (your current lock screen wallpaper will be replaced; "
                        + "the home screen wallpaper stays the same).\n\n"
                        + "Every time you turn your phone off and on, a new quote appears.\n\n"
                        + "On Xiaomi, Huawei, Honor and some other phones, allow “Autostart” for the app "
                        + "in Settings. On Xiaomi, also turn off “Wallpaper carousel”."));
        help.setTextSize(14);
        help.setTextColor(cText);
        help.setAlpha(0.85f);
        help.setLineSpacing(0, 1.2f);
        root.addView(help);

        TextView note = new TextView(this);
        note.setText(t("Перевод изречений — вольный пересказ с пали.",
                "Verses are a free rendering from the Pali."));
        note.setTextSize(12);
        note.setTextColor(cMuted);
        note.setPadding(0, (int) (16 * d), 0, 0);
        root.addView(note);

        setContentView(scroll);
        showCurrent();
        QuoteWidgetProvider.updateAll(this);
    }

    private LinearLayout.LayoutParams lp(int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = (int) (topDp * d);
        return lp;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTextColor(cBtnText);
        b.setBackgroundTintList(ColorStateList.valueOf(cBtn));
        return b;
    }

    private Switch sw(String text) {
        Switch s = new Switch(this);
        s.setText(text);
        s.setTextSize(16);
        s.setTextColor(cText);
        s.setPadding(0, (int) (14 * d), 0, (int) (14 * d));
        ColorStateList thumb = new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                new int[]{cGold, Settings.dark(this) ? Color.parseColor("#8A7F72") : Color.parseColor("#FFFFFF")});
        ColorStateList track = new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                new int[]{Color.parseColor("#80D4AF6A"), Color.parseColor("#55888888")});
        s.setThumbTintList(thumb);
        s.setTrackTintList(track);
        return s;
    }

    private TextView header(String text) {
        TextView h = new TextView(this);
        h.setText(text);
        h.setTextSize(13);
        h.setLetterSpacing(0.08f);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        h.setTextColor(cGold);
        h.setPadding(0, (int) (28 * d), 0, (int) (6 * d));
        return h;
    }

    /** Обновить виджеты и (если включено) экран блокировки. */
    private void refreshEverywhere(boolean toast) {
        QuoteWidgetProvider.updateAll(this);
        if (LockScreen.isEnabled(this)) updateLockScreen(toast);
    }

    private void updateLockScreen(boolean showToast) {
        new Thread(() -> {
            boolean ok = LockScreen.apply(getApplicationContext());
            if (showToast) {
                runOnUiThread(() -> Toast.makeText(this,
                        ok ? t("Готово — посмотрите на экран блокировки", "Done — check your lock screen")
                           : t("Не удалось поставить обои", "Could not set the wallpaper"),
                        Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void showCurrent() {
        int idx = QuoteStore.current(this);
        boolean en = Settings.english(this);
        quoteView.setText(Quotes.text(idx, en));
        sourceView.setText(Quotes.source(idx, en));
    }
}
