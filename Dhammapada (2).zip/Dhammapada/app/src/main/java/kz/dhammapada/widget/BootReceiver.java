package kz.dhammapada.widget;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;

/** Срабатывает при включении телефона: новая цитата на виджете и на экране блокировки. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        long bootTime = System.currentTimeMillis() - SystemClock.elapsedRealtime();
        boolean isNewBoot = QuoteStore.markBoot(context, bootTime);
        if (isNewBoot) {
            QuoteStore.next(context);
        }
        QuoteWidgetProvider.updateAll(context);
        if (isNewBoot) {
            final Context app = context.getApplicationContext();
            final PendingResult result = goAsync();
            new Thread(() -> {
                try {
                    LockScreen.applyIfEnabled(app);
                } finally {
                    result.finish();
                }
            }).start();
        }
    }
}
