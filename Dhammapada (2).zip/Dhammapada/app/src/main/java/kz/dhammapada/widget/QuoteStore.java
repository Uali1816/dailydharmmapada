package kz.dhammapada.widget;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Random;

/** Хранит номер текущей цитаты и умеет выбирать новую. */
final class QuoteStore {
    private static final String PREFS = "quotes";
    private static final String KEY_INDEX = "index";
    private static final String KEY_BOOT = "boot_time";

    private QuoteStore() {}

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Номер текущей цитаты (если ещё не выбрана — выбирает случайную). */
    static int current(Context c) {
        SharedPreferences p = prefs(c);
        int idx = p.getInt(KEY_INDEX, -1);
        if (idx < 0 || idx >= Quotes.ALL.length) {
            idx = next(c);
        }
        return idx;
    }

    /** Выбирает новую случайную цитату, отличную от текущей. */
    static int next(Context c) {
        SharedPreferences p = prefs(c);
        int old = p.getInt(KEY_INDEX, -1);
        int n = Quotes.ALL.length;
        int idx = new Random().nextInt(n);
        if (n > 1 && idx == old) {
            idx = (idx + 1 + new Random().nextInt(n - 1)) % n;
        }
        p.edit().putInt(KEY_INDEX, idx).apply();
        return idx;
    }

    /**
     * Вызывается при загрузке телефона. Возвращает true, если это новая загрузка
     * (защита от повторного срабатывания, когда система шлёт несколько сигналов).
     */
    static boolean markBoot(Context c, long bootTimeMillis) {
        SharedPreferences p = prefs(c);
        long last = p.getLong(KEY_BOOT, 0);
        if (Math.abs(bootTimeMillis - last) < 60_000) {
            return false;
        }
        p.edit().putLong(KEY_BOOT, bootTimeMillis).apply();
        return true;
    }
}
