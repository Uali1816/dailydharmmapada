package kz.dhammapada.widget;

import android.app.WallpaperManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Build;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.DisplayMetrics;
import android.view.WindowManager;

/** Рисует цитату на картинке и ставит её обоями экрана блокировки. */
final class LockScreen {
    private static final String PREFS = "quotes";
    private static final String KEY_ENABLED = "lock_enabled";

    private LockScreen() {}

    static boolean isEnabled(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(KEY_ENABLED, false);
    }

    static void setEnabled(Context c, boolean on) {
        SharedPreferences p = c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        p.edit().putBoolean(KEY_ENABLED, on).apply();
    }

    /** Поставить текущую цитату на экран блокировки (если включено). Вызывать НЕ в главном потоке. */
    static boolean applyIfEnabled(Context c) {
        if (!isEnabled(c)) return false;
        return apply(c);
    }

    static boolean apply(Context c) {
        try {
            int[] size = screenSize(c);
            int idx = QuoteStore.current(c);
            boolean en = Settings.english(c);
            Bitmap bmp = render(c, size[0], size[1], Quotes.text(idx, en), Quotes.source(idx, en));
            WallpaperManager.getInstance(c).setBitmap(bmp, null, true, WallpaperManager.FLAG_LOCK);
            bmp.recycle();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    @SuppressWarnings("deprecation")
    private static int[] screenSize(Context c) {
        WindowManager wm = c.getSystemService(WindowManager.class);
        if (Build.VERSION.SDK_INT >= 30) {
            Rect b = wm.getMaximumWindowMetrics().getBounds();
            return new int[]{Math.min(b.width(), b.height()), Math.max(b.width(), b.height())};
        }
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        return new int[]{Math.min(dm.widthPixels, dm.heightPixels), Math.max(dm.widthPixels, dm.heightPixels)};
    }

    private static Bitmap render(Context c, int w, int h, String text, String source) {
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);

        // Фон — тёплый тёмный градиент
        Paint bg = new Paint();
        bg.setShader(new LinearGradient(0, 0, 0, h,
                new int[]{Color.parseColor("#2B241D"), Color.parseColor("#17130F"), Color.parseColor("#0D0B09")},
                null, Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, w, h, bg);

        int gold = Color.parseColor("#D4AF6A");
        int margin = (int) (w * 0.11f);
        int textWidth = w - margin * 2;

        // Текст цитаты: подбираем размер, чтобы влез примерно в 38% высоты
        TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        tp.setColor(Color.parseColor("#F5EFE6"));
        tp.setTypeface(Typeface.create(Typeface.SERIF, Typeface.NORMAL));
        float size = w * 0.06f;
        StaticLayout layout;
        do {
            tp.setTextSize(size);
            layout = StaticLayout.Builder.obtain(text, 0, text.length(), tp, textWidth)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .setLineSpacing(0, 1.18f)
                    .build();
            size -= w * 0.002f;
        } while (layout.getHeight() > h * 0.38f && size > w * 0.03f);

        TextPaint sp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        sp.setColor(gold);
        sp.setTextSize(w * 0.036f);
        sp.setLetterSpacing(0.08f);
        sp.setTextAlign(Paint.Align.CENTER);

        float wheelR = w * 0.045f;
        float gap = w * 0.06f;
        float block = wheelR * 2 + gap + layout.getHeight() + gap + sp.getTextSize();
        // Центр блока чуть ниже середины, чтобы не мешать часам вверху
        float top = h * 0.58f - block / 2f;

        drawWheel(cv, w / 2f, top + wheelR, wheelR, gold);

        cv.save();
        cv.translate(margin, top + wheelR * 2 + gap);
        layout.draw(cv);
        cv.restore();

        cv.drawText(source, w / 2f, top + wheelR * 2 + gap + layout.getHeight() + gap + sp.getTextSize(), sp);
        return bmp;
    }

    private static void drawWheel(Canvas cv, float cx, float cy, float r, int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(r * 0.12f);
        cv.drawCircle(cx, cy, r, p);
        cv.drawCircle(cx, cy, r * 0.22f, p);
        for (int i = 0; i < 8; i++) {
            double a = Math.PI * 2 * i / 8;
            cv.drawLine(cx + (float) (r * 0.22f * Math.cos(a)), cy + (float) (r * 0.22f * Math.sin(a)),
                    cx + (float) (r * Math.cos(a)), cy + (float) (r * Math.sin(a)), p);
        }
    }
}
